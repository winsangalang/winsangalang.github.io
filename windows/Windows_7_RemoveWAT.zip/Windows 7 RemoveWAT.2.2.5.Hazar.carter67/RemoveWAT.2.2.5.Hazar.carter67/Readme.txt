To run silently please use /s
it will reboot your system so place at end of setup if you are integrating it