Use this license key:

14h51xkk-9zs2535e-c913ys8a-xrdgqvts-8mk63qax

1.Install Deep Freeze,use the license key above.

2.Wait for it to reboot then put it to THAWED State.Reboot.

3.Use the Application called PC Hunter to copy Persi0.sys (Located in Drive C) into desktop or any location of your choice.

4.Activate the patch and point it to the location of the copied Persi0.sys.If you are to select BACKUP feature,
  it will create Persi0.sys.BAK.This was the original Persi0.sys.You may want to keep it....or not.

5.Use PC Hunter again to rename the Persi0.sys (Located in Drive C) to any name you want.

6.Copy the PATCHED Persi0.sys and Paste it to Drive C.Since the original Persi0.sys was renamed you can paste 
  the PATCHED Persi0.sys flawlessly.

7.You can delete the renamed Persi0.sys if you want using PC Hunter.

8.Restart your PC.Done.


NOTE: Please delete this after crack the Deep Freeze!

LaCe12